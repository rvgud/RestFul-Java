package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;

import bean.User;

public class Createdb {
	private static final String DRIVER="org.h2.Driver";
	private static final String DB_PATH = "jdbc:h2:./Database/user";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "1234";
	/*public static void main(String[] a)  throws Exception {
    createdb db=new createdb();
     connection connetion=createdbconnection();
     db.create_new_user("ravi"."1234");
    }*/
	private static Connection createdDBConnection() throws Exception {
		Connection dbconnection=null;
		try {
			Class.forName(DRIVER);
		} 
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbconnection=DriverManager.getConnection(DB_PATH, DB_USER,DB_PASSWORD);
			createTables(dbconnection);
			return dbconnection;
		} catch (SQLException e){
			System.out.println(e.getMessage());
		}
		return dbconnection;
	}
	private static void createTables(Connection connection) throws Exception{
		Statement stmt =null;
		try {
			connection.setAutoCommit(false);
			stmt =connection.createStatement();
			stmt.execute("CREATE TABLE IF NOT EXISTS users(id varchar(255) primary key,password varchar(255))");
			stmt.execute("CREATE TABLE IF NOT EXISTS login(id varchar(255), timestamp TIMESTAMP)");
			stmt.execute("CREATE TABLE IF NOT EXISTS logout(id varchar(255), timestamp TIMESTAMP)");
			stmt.close();
			connection.commit();

		}catch (SQLException e) {
			System.out.println("Exception message in create table" + e.getLocalizedMessage());

		}catch (Exception e) {
			e.printStackTrace();
		}finally {

		}
	}
	public void create_new_user(String uname,String pass) throws Exception {
		Connection connection=createdDBConnection();
		PreparedStatement insertpreparedstatement = null;
		try {
			connection.setAutoCommit(false);
			insertpreparedstatement=connection.prepareStatement("INSERT INTO users VALUES(?,?)");
			insertpreparedstatement.setString(1,uname);
			insertpreparedstatement.setString(2,pass);
			insertpreparedstatement.executeUpdate();
			insertpreparedstatement.close();
			connection.commit();
			System.out.println("user created");

		}
		catch (SQLException e) {
			System.out.println("Exception message in create table" + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}
	public void login_entry(String uname) throws Exception{
		Connection connection=createdDBConnection();
		PreparedStatement insertpreparedstatement = null;
		try
		{
			connection.setAutoCommit(false);
			insertpreparedstatement=connection.prepareStatement("INSERT INTO login VALUES(?,?)");
			insertpreparedstatement.setString(1,uname);
			Timestamp timestamp=new Timestamp(new Date().getTime());
			insertpreparedstatement.setTimestamp(2,timestamp);
			insertpreparedstatement.executeUpdate();
			insertpreparedstatement.close();
			connection.commit();
		}catch (SQLException e){
			System.out.println("Exception message in create table" + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}
	public void logout_entry(String uname) throws Exception{
		Connection connection=createdDBConnection();
		PreparedStatement insertpreparedstatement=null;
		try{
			connection.setAutoCommit(false);
			insertpreparedstatement=connection.prepareStatement("INSERT INTO logout VALUES(?,?)");
			insertpreparedstatement.setString(1,uname);
			Timestamp timestamp=new Timestamp(new Date().getTime());
			insertpreparedstatement.setTimestamp(2,timestamp);
			insertpreparedstatement.executeUpdate();
			insertpreparedstatement.close();
			connection.commit();
		}catch (SQLException e){
			System.out.println("Exception message in create table" + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}
	public boolean check_user(String uname) throws Exception{
		Connection connection=createdDBConnection();
		boolean user=false;
		try{
			connection.setAutoCommit(false);
			PreparedStatement selectPreparedStataemnt =connection.prepareStatement("select id from users where id=?");
			selectPreparedStataemnt.setString(1,uname);
			ResultSet rs=selectPreparedStataemnt.executeQuery();
			while(rs.next()){
				user=true;
			}
			selectPreparedStataemnt.close();
			connection.commit();
		}
		catch (SQLException e){
			System.out.println("Exception message " + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return user;
	}
	public boolean validate_user(String uname,String password) throws Exception{
		Connection connection=createdDBConnection();
		boolean user=false;
		try{
			connection.setAutoCommit(false);
			PreparedStatement selectPreparedStataemnt =connection.prepareStatement("select id from users where id=? and password=?");
			selectPreparedStataemnt.setString(1,uname);
			selectPreparedStataemnt.setString(2,password);
			ResultSet rs=selectPreparedStataemnt.executeQuery();
			while(rs.next()){
				user=true;
				this.login_entry(uname);
			};
			connection.commit();
		}
		catch (SQLException e){
			System.out.println("Exception message " + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return user;
	}

	public Date check_user_last_login(String uname) throws Exception{
		Connection connection=createdDBConnection();
		Date last_login_time=null;
		try{
			connection.setAutoCommit(false);
			PreparedStatement selectPreparedStataemnt =connection.prepareStatement("select max(timestamp) as timestamp from login where id=?");
			selectPreparedStataemnt.setString(1,uname);
			ResultSet rs=selectPreparedStataemnt.executeQuery();
			while(rs.next()){
				last_login_time=rs.getTimestamp("timestamp");
			}
			selectPreparedStataemnt.close();
			connection.commit();
		}
		catch (SQLException e){
			System.out.println("Exception message " + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return last_login_time;
	}

	public Date check_user_last_logout(String uname) throws Exception{
		Connection connection=createdDBConnection();
		Date last_logout_time=null;
		try{
			connection.setAutoCommit(false);
			PreparedStatement selectPreparedStataemnt =connection.prepareStatement("select max(timestamp) as timestamp from logout where id=?");
			selectPreparedStataemnt.setString(1,uname);
			ResultSet rs=selectPreparedStataemnt.executeQuery();
			while(rs.next()){
				last_logout_time=rs.getTimestamp("timestamp");
			}
			selectPreparedStataemnt.close();
			connection.commit();
		}
		catch (SQLException e){
			System.out.println("Exception message " + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return last_logout_time;
	}
	public void show_all_user() throws Exception {
		Connection connection=createdDBConnection();
		Statement stmt=null;
		try {
			connection.setAutoCommit(false);
			stmt=connection.createStatement();
			ResultSet rs =stmt.executeQuery("select * from users");
			while(rs.next()){
				System.out.println("uname" + rs.getString("id")+"password"+rs.getString("password"));

			}
			stmt.close();
			connection.commit();

		}catch (SQLException e){
			System.out.println("Exception message " + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}
	public User get_user_details(String uname) throws Exception {
		Connection connection=createdDBConnection();
		User user=null;
		try{
			connection.setAutoCommit(false);
			PreparedStatement selectPreparedStataemnt =connection.prepareStatement("select * from users where id=?");
			selectPreparedStataemnt.setString(1,uname);
			ResultSet rs=selectPreparedStataemnt.executeQuery();
			while(rs.next()){
				user=new User();
				user.setUname(rs.getString("id"));
			}
			selectPreparedStataemnt.close();
			connection.commit();
		}
		catch (SQLException e){
			System.out.println("Exception message " + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return user;
	}
}
