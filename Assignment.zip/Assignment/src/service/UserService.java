package service;
import java.util.Date;

import bean.User;
import dao.Createdb;
public class UserService {
	public User get_user(String uname,String password){
		Createdb db=new Createdb();
		User user=null;
		if(this.login_user(uname, password)){
			try{
			user=db.get_user_details(uname);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else{
			user=new User();
			user.setMessage("Invalid username or password!");
		}
		return user;
		
	}
	public boolean check_user(String uname){
		Createdb db=new Createdb();
		boolean user_exist=false;
		try{
			user_exist=db.check_user(uname);

		}catch(Exception e) {
			//to do auto-generated catch block
			e.printStackTrace();

		}
		return user_exist;

	}
	public boolean login_user(String uname,String password){
		Createdb db=new Createdb();
		boolean user_exist=false;
		try{
			user_exist=db.validate_user(uname,password);

		}catch(Exception e) {
			//to do auto-generated catch block
			e.printStackTrace();

		}
		return user_exist;

	}
	public boolean logout_user(String uname){
		Createdb db=new Createdb();
		boolean user_logout=true;
		try{
			db.logout_entry(uname);

		}catch(Exception e) {
			//to do auto-generated catch block
			e.printStackTrace();

		}
		return user_logout;

	}
	public Date check_user_login_time(String uname){
		Createdb db=new Createdb();
		Date last_login_time=null;
		try{
			last_login_time=db.check_user_last_login(uname);
		}catch(Exception e) {
			//to do auto-generated catch block
			e.printStackTrace();

		}
		return last_login_time;

	}

	public String check_user_login(String uname){
		Createdb db=new Createdb();
		Date last_login_time=null;
		Date last_logout_time=null;
		String status="logout";
		try{
			if(db.check_user(uname)){
			last_logout_time=db.check_user_last_logout(uname);
			last_login_time=db.check_user_last_login(uname);
			if(last_login_time==null){
				status="never logged in";

			}
			else if(last_logout_time==null){
				status="login";
			}
			else{
				if(last_logout_time.after(last_login_time)){
					status="logout";
				}
				else{
					status="login";
				}
			}
			}
			else{
				status="No User found with this username";
			}
		}catch(Exception e) {
			//to do auto-generated catch block
			e.printStackTrace();

		}
		return status;
	}

	public boolean create_user(String uname,String password){
		Createdb db=new Createdb();

		try{
			db.create_new_user(uname,password);
			return true;
		}catch(Exception e) {
			//to do auto-generated catch block
			e.printStackTrace();

		}
		return false;

	}
}
