package bean;
public class User {
	private String uname;
	private String password;
	private String message;

	public String getUname() {
		return this.uname;
	}
	public void setUname(String uname) {
		this.uname=uname;
	}
	public String getPassword() {
		return this.password;
	}
	public void setPassword(String password) {
		this.password=password;
	}
	public String getMessage() {
		return this.message;
	}
	public void setMessage(String message) {
		this.message=message;
	}
}