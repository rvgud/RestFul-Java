package API;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import service.UserService;

import bean.User;

@Path("/Users")
public class Client {
	@POST
	@Path("/User_login")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getUserDetails(String datarecieved) throws Exception{
		Response response=null;
		Gson g = new Gson();
		User user =g.fromJson(datarecieved,User.class);
		try{
			UserService uservice=new UserService();
			User UserInfomation=uservice.get_user(user.getUname(), user.getPassword());
			String returnString=g.toJson(UserInfomation);
			response=Response.ok(returnString).build();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(response.getEntity().toString());
		return response;
	}
	@POST
	@Path("/Users_signup")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response user_signup(String datarecieved) throws Exception{
		Response response=null;
		Gson g = new Gson();
		User user =g.fromJson(datarecieved,User.class);
		try{
			UserService uservice=new UserService();
			if(uservice.check_user(user.getUname())){
				User Beanformessage=new User();
				Beanformessage.setMessage("User already exist with this username.");
				String returnString=g.toJson(Beanformessage);
				response=Response.ok(returnString).build();
				System.out.println(response.getEntity().toString());
				return response;
			}
			uservice.create_user(user.getUname(), user.getPassword());
			User UserInfomation=uservice.get_user(user.getUname(), user.getPassword());
			String returnString=g.toJson(UserInfomation);
			System.out.println("user created"+returnString);
			response=Response.ok(returnString).build();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(response.getEntity().toString());
		return response;
	}
	@POST
	@Path("/Users_login_details")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getuserlogin(String datarecieved) throws Exception{
		Response response=null;
		Gson g = new Gson();
		User user =g.fromJson(datarecieved,User.class);
		try{
			UserService uservice=new UserService();
			User UserInfomation=new User();
			UserInfomation.setMessage(uservice.check_user_login(user.getUname()));
			String returnString=g.toJson(UserInfomation);
			response=Response.ok(returnString).build();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(response.getEntity().toString());
		return response;
	}
	@POST
	@Path("/Users_logout")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getuserlogout(String datarecieved) throws Exception{
		Response response=null;
		Gson g = new Gson();
		User user =g.fromJson(datarecieved,User.class);
		try{
			UserService uservice=new UserService();
			User UserInfomation=new User();
			uservice.logout_user(user.getUname());
			UserInfomation.setMessage("Logout successful");
			String returnString=g.toJson(UserInfomation);
			response=Response.ok(returnString).build();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(response.getEntity().toString());
		return response;
	}
}