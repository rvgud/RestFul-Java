 var URI=getURI;
 var assignment = angular.module("Application", ['ngCookies']);
 assignment.config(function($httpProvider){
 	$httpProvider.defaults.headers.post['Content-Type']="application/json; charset=UTF-8";
 	$httpProvider.defaults.headers.post["Data-Type"]="json";

 });
 assignment.controller(
			"LoginController",
		function($scope,$http,$cookies){
				$scope.loginForm={};
				$scope.loginForm.message=null;
				$scope.loginForm.checkUserDetails=function(){
					var data=angular.toJson($scope.loginForm);
					var responsePromise=$http.post(URI+"User_login",data);
					responsePromise.then(
					function(response){
						if(response.data.uname==null){
							$scope.loginForm.message=response.data.message;
						}
						else{
							$cookies.put("name",response.data.uname);
							window.location="partials/userHome.html";
						}
					},
					function(response){
						$scope.loginForm.message=response.data.message;
					}
					);
				}
				$scope.loginForm.signup=function(){
					var data=angular.toJson($scope.loginForm);
					var responsePromise=$http.post(URI+"Users_signup",data);
					responsePromise.then(
					function(response){
						if(response.data.uname==null){
							$scope.loginForm.message=response.data.message;
						}
						else{
							$cookies.put("name",response.data.uname);
							window.location="partials/userHome.html";
						}
					},
					function(response){
						$scope.loginForm.message=response.data.message;
					}
					);
				}
				$scope.checkForm={};
				$scope.checkForm.message=null;
				$scope.checkForm.checkUserLogin=function(){
					$scope.checkForm.message=null;
					var data=angular.toJson($scope.checkForm);
					var responsePromise=$http.post(URI+"Users_login_details",data);
					responsePromise.then(
					function(response){
						$scope.checkForm.message=response.data.message;
					},
					function(response){
						$scope.checkForm.message=response.data.message;
					}
					);
				}
			});