assignment.controller(
	"UserProfileController",
function($scope,$http,$cookies){
	$scope.getUserName=function(){
		if($cookies.get('name')==null) {
			window.location="../index.html";
		}
		else{
			$scope.username=$cookies.get('name');

		}
	}
	$scope.logout=function(){
		var data={};
		data.uname=$cookies.get('name');
		var responsePromise=$http.post(URI+"Users_logout",data);
		$cookies.remove('name',{path: '/Assignment'});
		window.location="../index.html";

	}
});